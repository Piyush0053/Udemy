let isMotionCompensationEnabled = false;
let isVoiceControlEnabled = false;

// Motion Compensation: Stabilize Text
window.addEventListener("devicemotion", (event) => {
  if (!isMotionCompensationEnabled) return;

  let acceleration = event.accelerationIncludingGravity;
  if (acceleration) {
    let offsetX = acceleration.x * -2; // Adjust sensitivity
    let offsetY = acceleration.y * -2;

    document.body.style.transform = `translate(${offsetX}px, ${offsetY}px)`;
  }
});

// Toggle Motion Compensation
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "toggleMotion") {
    isMotionCompensationEnabled = !isMotionCompensationEnabled;
    document.body.style.transform = isMotionCompensationEnabled ? "translate(0, 0)" : "";
  } else if (message.action === "toggleVoice") {
    isVoiceControlEnabled = !isVoiceControlEnabled;
    if (isVoiceControlEnabled) startVoiceRecognition();
  }
});

// Voice Control: Speech Recognition
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const recognition = new SpeechRecognition();

recognition.continuous = true;
recognition.interimResults = false;

function startVoiceRecognition() {
  recognition.start();
}

recognition.onresult = (event) => {
  const command = event.results[event.results.length - 1][0].transcript.toLowerCase();
  console.log("Voice Command: ", command);

  if (command.includes("scroll up")) {
    window.scrollBy(0, -200);
  } else if (command.includes("scroll down")) {
    window.scrollBy(0, 200);
  } else if (command.includes("read text")) {
    readText();
  }
};

// Text-to-Speech Function
function readText() {
  let selectedText = window.getSelection().toString();
  if (!selectedText) {
    selectedText = document.body.innerText.substring(0, 500); // Read first 500 characters
  }

  let utterance = new SpeechSynthesisUtterance(selectedText);
  utterance.rate = 1;
  utterance.pitch = 1;
  speechSynthesis.speak(utterance);
}
